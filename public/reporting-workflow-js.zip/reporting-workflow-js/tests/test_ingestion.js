'use strict';

const fs = require('fs');
const path = require('path');
const assert = require('assert');

const { ingestAndProfile } = require('../src/data_ingestion');
const { setupLogging } = require('../src/utils/logging');

setupLogging('INFO');

const SAMPLE_PATH = path.join(__dirname, 'sample.csv');

function makeSampleCsv() {
  const rows = [
    ['date', 'sales', 'region', 'mostly_missing'],
    ['2023-01-01', '100', 'North', ''],
    ['2023-01-02', '200', 'South', ''],
    ['2023-01-03', '300', 'North', ''],
    ['2023-01-04', '250', 'East', ''],
    ['2023-01-05', '9000', 'North', ''], // outlier + all mostly_missing empty -> 100% missing
  ];
  const csv = rows.map((r) => r.join(',')).join('\n');
  fs.writeFileSync(SAMPLE_PATH, csv);
}

async function main() {
  makeSampleCsv();

  // 1. Profile without auto-clean
  const profile = await ingestAndProfile(SAMPLE_PATH, { autoClean: false });
  console.log('\n=== PROFILE (no auto-clean) ===');
  console.log('Original shape:', profile.originalShape);
  console.log('Missing summary:', profile.missingSummary);
  console.log('Outlier summary:', profile.outlierSummary);
  console.log('Recommendations:');
  profile.recommendations.forEach((r) => console.log('  -', r));
  console.log('Sample data:', profile.sampleData);

  assert.deepStrictEqual(
    profile.cleanedTable.shape,
    profile.originalShape,
    'cleanedTable should equal raw table when autoClean=false'
  );

  // 2. Profile WITH auto-clean
  const profile2 = await ingestAndProfile(SAMPLE_PATH, { autoClean: true });
  console.log('\n=== PROFILE (auto-clean) ===');
  console.log('Original shape:', profile2.originalShape);
  console.log('Cleaned shape:', profile2.cleanedTable.shape);
  console.log('Cleaned columns:', profile2.cleanedTable.columns);
  console.log('Cleaned sample row 0:', profile2.cleanedTable.rows[0]);

  assert.ok(
    !profile2.cleanedTable.columns.includes('mostly_missing'),
    'high-missing column should be dropped'
  );
  assert.ok(
    profile2.cleanedTable.rows[0].date instanceof Date,
    'date column should be converted to a Date object'
  );

  // 3. Sanity check on outlier detection
  const salesOutliers = profile.columns.sales.outliers;
  console.log('\nDetected sales outliers:', salesOutliers);
  assert.ok(salesOutliers && salesOutliers.includes(9000), '9000 should be flagged as an outlier');

  // 4. Sanity check toDict() is JSON-serialisable
  const json = JSON.stringify(profile.toDict());
  assert.ok(json.length > 0);
  console.log('\ntoDict() JSON-serialisable: OK');

  console.log('\nALL CHECKS PASSED');
  fs.unlinkSync(SAMPLE_PATH);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
