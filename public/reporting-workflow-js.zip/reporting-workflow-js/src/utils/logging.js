'use strict';

const LEVELS = { DEBUG: 10, INFO: 20, WARNING: 30, ERROR: 40 };

class Logger {
  constructor(name, level = 'INFO') {
    this.name = name;
    this.level = LEVELS[level] ?? LEVELS.INFO;
  }

  _log(levelName, msg, ...args) {
    if (LEVELS[levelName] < this.level) return;
    const ts = new Date().toISOString().replace('T', ' ').slice(0, 19);
    const formatted = args.length ? `${msg} ${args.map((a) => JSON.stringify(a)).join(' ')}` : msg;
    // eslint-disable-next-line no-console
    console.log(`${ts} | ${levelName.padEnd(7)} | ${this.name} | ${formatted}`);
  }

  debug(msg, ...args) { this._log('DEBUG', msg, ...args); }
  info(msg, ...args) { this._log('INFO', msg, ...args); }
  warning(msg, ...args) { this._log('WARNING', msg, ...args); }
  error(msg, ...args) { this._log('ERROR', msg, ...args); }
}

let globalLevel = 'INFO';

function setupLogging(level = 'INFO') {
  globalLevel = level;
}

function getLogger(name) {
  return new Logger(name, globalLevel);
}

module.exports = { setupLogging, getLogger };
