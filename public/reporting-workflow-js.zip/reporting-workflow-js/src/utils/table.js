'use strict';

/**
 * A minimal, dependency-free "DataFrame-like" table: an ordered list of
 * column names + an array of row objects. Provides just enough of pandas'
 * surface area (dtype inference, stats, quantiles, mode) for profiling.
 */
class Table {
  /**
   * @param {string[]} columns  ordered column names
   * @param {Object[]} rows     array of row objects keyed by column name
   */
  constructor(columns, rows) {
    this.columns = columns;
    this.rows = rows;
  }

  get shape() {
    return [this.rows.length, this.columns.length];
  }

  head(n = 5) {
    return this.rows.slice(0, n);
  }

  clone() {
    return new Table(
      [...this.columns],
      this.rows.map((r) => ({ ...r }))
    );
  }

  dropColumn(col) {
    this.columns = this.columns.filter((c) => c !== col);
    for (const row of this.rows) delete row[col];
  }

  getColumnValues(col) {
    return this.rows.map((r) => r[col]);
  }

  setColumnValues(col, values) {
    for (let i = 0; i < this.rows.length; i++) this.rows[i][col] = values[i];
  }

  static isMissing(value) {
    if (value === null || value === undefined || value === '') return true;
    if (typeof value === 'number' && Number.isNaN(value)) return true;
    return false;
  }
}

/** Non-null, non-missing values for a column. */
function nonNullValues(table, col) {
  return table.getColumnValues(col).filter((v) => !Table.isMissing(v));
}

/** True if every non-null value in the column looks numeric. */
function isNumericColumn(values) {
  if (values.length === 0) return false;
  return values.every((v) => typeof v === 'number' && Number.isFinite(v));
}

// JS's Date.parse is far too lenient (e.g. it happily "parses" "ORD-00000"),
// so date-likeness is checked against an explicit whitelist of common
// unambiguous formats rather than trusting Date.parse's leniency alone.
const DATE_PATTERNS = [
  /^\d{4}-\d{2}-\d{2}(T\d{2}:\d{2}(:\d{2})?(\.\d+)?(Z|[+-]\d{2}:?\d{2})?)?$/, // ISO 8601
  /^\d{4}\/\d{2}\/\d{2}$/, // 2023/01/31
  /^\d{2}\/\d{2}\/\d{4}$/, // 01/31/2023 or 31/01/2023
  /^\d{1,2}-[A-Za-z]{3}-\d{4}$/, // 31-Jan-2023
  /^[A-Za-z]{3,9}\s+\d{1,2},?\s+\d{4}$/, // January 31, 2023 / Jan 31 2023
];

/** Heuristic date detection: sample first N non-null values against a format whitelist. */
function looksLikeDate(values, sampleSize = 10) {
  const sample = values.slice(0, sampleSize);
  if (sample.length === 0) return false;
  return sample.every((v) => {
    if (typeof v !== 'string') return false;
    const trimmed = v.trim();
    if (!DATE_PATTERNS.some((re) => re.test(trimmed))) return false;
    return !Number.isNaN(Date.parse(trimmed));
  });
}

function mean(values) {
  if (values.length === 0) return null;
  return values.reduce((a, b) => a + b, 0) / values.length;
}

function stddev(values) {
  if (values.length < 2) return values.length === 1 ? 0 : null;
  const m = mean(values);
  const variance = values.reduce((a, b) => a + (b - m) ** 2, 0) / (values.length - 1);
  return Math.sqrt(variance);
}

/** Linear-interpolation percentile, matching pandas/numpy default behaviour. */
function quantile(sortedValues, q) {
  if (sortedValues.length === 0) return null;
  if (sortedValues.length === 1) return sortedValues[0];
  const pos = (sortedValues.length - 1) * q;
  const base = Math.floor(pos);
  const rest = pos - base;
  if (sortedValues[base + 1] !== undefined) {
    return sortedValues[base] + rest * (sortedValues[base + 1] - sortedValues[base]);
  }
  return sortedValues[base];
}

function median(values) {
  const sorted = [...values].sort((a, b) => a - b);
  return quantile(sorted, 0.5);
}

/** Most frequent value + its count. Ties broken by first-seen order. */
function mode(values) {
  const counts = new Map();
  for (const v of values) counts.set(v, (counts.get(v) || 0) + 1);
  let best = null;
  let bestCount = -1;
  for (const v of values) {
    const c = counts.get(v);
    if (c > bestCount) {
      best = v;
      bestCount = c;
    }
  }
  return { value: best, freq: bestCount < 0 ? 0 : bestCount };
}

function uniqueCount(values) {
  return new Set(values).size;
}

module.exports = {
  Table,
  nonNullValues,
  isNumericColumn,
  looksLikeDate,
  mean,
  stddev,
  quantile,
  median,
  mode,
  uniqueCount,
};
