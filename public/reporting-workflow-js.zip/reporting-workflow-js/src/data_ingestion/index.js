'use strict';

const { DataLoader } = require('./loader');
const { DataProfiler } = require('./profiler');
const { getLogger } = require('../utils/logging');

const logger = getLogger('data_ingestion');

/**
 * Load data from `source` and produce a profile.
 *
 * @param {string|Object} source  file path, or a DB source object (see loader.js)
 * @param {Object} [config]       see config.yaml -> data_ingestion for keys
 *   (accepts either camelCase or snake_case keys)
 * @returns {Promise<Object>} profile — `profile.cleanedTable` holds the
 *   (optionally auto-cleaned) Table for downstream stages.
 */
async function ingestAndProfile(source, config = {}) {
  const table = await DataLoader.load(source);
  logger.info(`Loaded data with shape [${table.shape.join(', ')}]`);

  const profiler = new DataProfiler(config);
  const profile = profiler.profile(table);

  const autoClean = config.autoClean ?? config.auto_clean ?? false;
  if (autoClean) {
    profile.cleanedTable = profiler.applyCleaning(table);
    logger.info(
      `Auto-cleaning applied: [${profile.originalShape.join(', ')}] -> [${profile.cleanedTable.shape.join(', ')}]`
    );
  } else {
    profile.cleanedTable = table;
  }

  return profile;
}

module.exports = { ingestAndProfile, DataLoader, DataProfiler };
