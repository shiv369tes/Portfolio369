'use strict';

const {
  Table,
  nonNullValues,
  isNumericColumn,
  looksLikeDate,
  mean,
  stddev,
  quantile,
  median,
  mode,
  uniqueCount,
} = require('../utils/table');
const { getLogger } = require('../utils/logging');

const logger = getLogger('data_ingestion.profiler');

class DataProfiler {
  constructor(config = {}) {
    this.config = config;
    this.missingThreshold = config.missingThreshold ?? config.missing_threshold ?? 0.8;
    this.imputeThreshold = config.imputeThreshold ?? config.impute_threshold ?? 0.1;
    this.outlierMethod = config.outlierMethod ?? config.outlier_method ?? 'iqr'; // 'iqr' | 'zscore'
    this.zscoreThreshold = config.zscoreThreshold ?? config.zscore_threshold ?? 3;

    /** Populated after profile() runs; used by applyCleaning() with no explicit actions. */
    this.columns = {};
  }

  /**
   * @param {Table} table
   * @returns {DataProfile}
   */
  profile(table) {
    logger.info(`Profiling table with shape [${table.shape.join(', ')}]`);

    const columns = {};
    const missingSummary = {};
    const outlierSummary = {};
    const recommendations = [];
    const nRows = Math.max(table.rows.length, 1);

    for (const col of table.columns) {
      const allValues = table.getColumnValues(col);
      const nonNull = nonNullValues(table, col);
      const nullCount = allValues.length - nonNull.length;
      const nullPercent = nullCount / nRows;
      missingSummary[col] = nullPercent;

      const numeric = isNumericColumn(nonNull);
      let stats;
      let outliers = null;

      if (numeric) {
        const sorted = [...nonNull].sort((a, b) => a - b);
        stats = {
          mean: mean(nonNull),
          std: stddev(nonNull),
          min: sorted[0] ?? null,
          max: sorted[sorted.length - 1] ?? null,
          q25: quantile(sorted, 0.25),
          q50: median(nonNull),
          q75: quantile(sorted, 0.75),
        };
        outliers = this._detectOutliers(nonNull);
        outlierSummary[col] = outliers.length;
      } else {
        const m = mode(nonNull);
        stats = { top: m.value, freq: m.freq };
        outlierSummary[col] = 0;
      }

      const cleaningActions = this._suggestCleaning(col, nonNull, numeric, nullPercent);

      columns[col] = {
        name: col,
        dtype: numeric ? 'number' : nonNull.length ? typeof nonNull[0] : 'unknown',
        nullCount,
        nullPercent,
        uniqueCount: uniqueCount(allValues),
        stats,
        outliers: outliers && outliers.length ? outliers : null,
        suggestedCleaning: cleaningActions,
      };
      recommendations.push(...cleaningActions);
    }

    this.columns = columns; // cache for applyCleaning()

    return {
      originalShape: table.shape,
      columns,
      missingSummary,
      outlierSummary,
      recommendations: [...new Set(recommendations)],
      sampleData: table.head(5),
      cleanedTable: null, // populated by ingestAndProfile() if autoClean is set
      toDict() {
        return {
          originalShape: this.originalShape,
          missingSummary: this.missingSummary,
          outlierSummary: this.outlierSummary,
          recommendations: this.recommendations,
          columns: Object.fromEntries(
            Object.entries(this.columns).map(([name, c]) => [
              name,
              {
                dtype: c.dtype,
                nullCount: c.nullCount,
                nullPercent: Math.round(c.nullPercent * 10000) / 10000,
                uniqueCount: c.uniqueCount,
                stats: c.stats,
                outliers: c.outliers,
                suggestedCleaning: c.suggestedCleaning,
              },
            ])
          ),
        };
      },
    };
  }

  _suggestCleaning(col, nonNullVals, numeric, nullPercent) {
    const actions = [];

    if (nullPercent > this.missingThreshold) {
      actions.push(`Drop column '${col}' (>${Math.round(this.missingThreshold * 100)}% missing)`);
    } else if (nullPercent > this.imputeThreshold) {
      actions.push(
        numeric
          ? `Impute missing values in '${col}' with median`
          : `Impute missing values in '${col}' with mode`
      );
    }

    if (!numeric && looksLikeDate(nonNullVals)) {
      actions.push(`Convert '${col}' to datetime`);
    }

    return actions;
  }

  _detectOutliers(values) {
    if (values.length === 0) return [];
    const sorted = [...values].sort((a, b) => a - b);

    if (this.outlierMethod === 'iqr') {
      const q1 = quantile(sorted, 0.25);
      const q3 = quantile(sorted, 0.75);
      const iqr = q3 - q1;
      const lower = q1 - 1.5 * iqr;
      const upper = q3 + 1.5 * iqr;
      return values.filter((v) => v < lower || v > upper).slice(0, 10);
    }
    if (this.outlierMethod === 'zscore') {
      const m = mean(values);
      const sd = stddev(values);
      if (!sd) return [];
      return values.filter((v) => Math.abs((v - m) / sd) > this.zscoreThreshold).slice(0, 10);
    }
    throw new Error(`Unknown outlier method: ${this.outlierMethod}`);
  }

  /**
   * Apply cleaning actions to a Table (mutates a clone, returns the clone).
   * @param {Table} table
   * @param {string[]} [actions] explicit actions; defaults to the last profile()'s recommendations
   */
  applyCleaning(table, actions = null) {
    const acts = actions ?? this._defaultActions();
    const clean = table.clone();

    for (const action of acts) {
      const colMatch = action.match(/'([^']+)'/);
      const col = colMatch ? colMatch[1] : null;
      if (!col || !clean.columns.includes(col)) continue;

      if (action.startsWith('Drop column')) {
        clean.dropColumn(col);
        logger.info(`Dropped column '${col}'`);
      } else if (action.startsWith('Impute missing values in')) {
        const values = nonNullValues(clean, col);
        let fillValue;
        if (action.includes('median')) fillValue = median(values);
        else if (action.includes('mode')) fillValue = mode(values).value;
        else continue;
        const updated = clean.getColumnValues(col).map((v) => (Table.isMissing(v) ? fillValue : v));
        clean.setColumnValues(col, updated);
        logger.info(`Imputed '${col}' with ${JSON.stringify(fillValue)}`);
      } else if (action.startsWith('Convert')) {
        const updated = clean
          .getColumnValues(col)
          .map((v) => (Table.isMissing(v) ? null : new Date(v)));
        clean.setColumnValues(col, updated);
        logger.info(`Converted '${col}' to datetime`);
      }
    }
    return clean;
  }

  _defaultActions() {
    const actions = [];
    for (const prof of Object.values(this.columns)) {
      actions.push(...prof.suggestedCleaning);
    }
    return [...new Set(actions)];
  }
}

module.exports = { DataProfiler };
