'use strict';

const fs = require('fs');
const path = require('path');
const { Table } = require('../utils/table');
const { getLogger } = require('../utils/logging');

const logger = getLogger('data_ingestion.loader');

const SUPPORTED_EXTENSIONS = new Set(['.csv', '.xlsx', '.xls', '.json']);

class DataLoader {
  /**
   * Load data from a file or a database source.
   *
   * @param {string|Object} source
   *   - file path (string) for CSV/XLSX/XLS/JSON, OR
   *   - a dict for database sources: { connectionString, query|table, adapter }
   *     where `adapter` is a user-supplied async function
   *     (connectionString, { query, table }) => Array<Object> of rows,
   *     since no DB driver ships with this module by default.
   * @returns {Table}
   */
  static async load(source) {
    if (typeof source === 'string') {
      return DataLoader._loadFile(source);
    }
    if (source && typeof source === 'object') {
      return DataLoader._loadDatabase(source);
    }
    throw new TypeError(
      `source must be a file path (string) or a database source object, got ${typeof source}`
    );
  }

  static _loadFile(filePath) {
    if (!fs.existsSync(filePath)) {
      throw new Error(`Source file not found: ${filePath}`);
    }
    const ext = path.extname(filePath).toLowerCase();
    if (!SUPPORTED_EXTENSIONS.has(ext)) {
      throw new Error(
        `Unsupported file type '${ext}'. Supported: ${[...SUPPORTED_EXTENSIONS].join(', ')}`
      );
    }

    logger.info(`Loading file ${filePath} (${ext})`);

    if (ext === '.csv') return DataLoader._loadCsv(filePath);
    if (ext === '.json') return DataLoader._loadJson(filePath);
    return DataLoader._loadExcel(filePath); // .xlsx / .xls
  }

  static _loadCsv(filePath) {
    const text = fs.readFileSync(filePath, 'utf8');
    const records = parseCsv(text);
    if (records.length === 0) return new Table([], []);

    const [header, ...dataRows] = records;
    const rows = dataRows.map((fields) => {
      const row = {};
      header.forEach((col, i) => {
        row[col] = coerceValue(fields[i]);
      });
      return row;
    });
    return new Table(header, rows);
  }

  static _loadJson(filePath) {
    const text = fs.readFileSync(filePath, 'utf8');
    const data = JSON.parse(text);
    const records = Array.isArray(data) ? data : data.records || data.data;
    if (!Array.isArray(records)) {
      throw new Error(
        'JSON source must be an array of row objects, or an object with a "records"/"data" array.'
      );
    }
    const columnSet = new Set();
    records.forEach((r) => Object.keys(r).forEach((k) => columnSet.add(k)));
    const columns = [...columnSet];
    return new Table(columns, records);
  }

  static _loadExcel(filePath) {
    let XLSX;
    try {
      // eslint-disable-next-line global-require, import/no-extraneous-dependencies
      XLSX = require('xlsx');
    } catch (err) {
      throw new Error(
        "Excel ingestion requires the 'xlsx' (SheetJS) package. Install it with " +
          '`npm install xlsx`.'
      );
    }
    const workbook = XLSX.readFile(filePath);
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const records = XLSX.utils.sheet_to_json(sheet, { defval: null });
    const columnSet = new Set();
    records.forEach((r) => Object.keys(r).forEach((k) => columnSet.add(k)));
    return new Table([...columnSet], records);
  }

  static async _loadDatabase(source) {
    const { connectionString, query, table, adapter } = source;
    if (!connectionString) {
      throw new Error("Missing 'connectionString' in source object");
    }
    if (typeof adapter !== 'function') {
      throw new Error(
        'Database ingestion needs a driver. This module ships without one to avoid ' +
          "forcing a specific DB client; pass `adapter: async (connectionString, {query, table}) => rows` " +
          "built on top of e.g. 'pg' (Postgres) or 'mysql2' (MySQL)."
      );
    }
    logger.info(query ? 'Running SQL query against database' : `Reading table '${table}' from database`);
    const rows = await adapter(connectionString, { query, table });
    const columnSet = new Set();
    rows.forEach((r) => Object.keys(r).forEach((k) => columnSet.add(k)));
    return new Table([...columnSet], rows);
  }
}

/** Convert a raw CSV string field into a number/null/string as appropriate. */
function coerceValue(field) {
  if (field === undefined || field === '') return null;
  const trimmed = field.trim();
  if (trimmed === '') return null;
  if (/^-?\d+(\.\d+)?$/.test(trimmed)) return Number(trimmed);
  return field;
}

/**
 * Minimal RFC-4180-ish CSV parser: handles quoted fields containing commas,
 * newlines, and escaped ("") quotes. Returns an array of arrays of strings.
 */
function parseCsv(text) {
  const rows = [];
  let row = [];
  let field = '';
  let inQuotes = false;
  const normalized = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

  for (let i = 0; i < normalized.length; i++) {
    const c = normalized[i];
    if (inQuotes) {
      if (c === '"') {
        if (normalized[i + 1] === '"') {
          field += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        field += c;
      }
    } else if (c === '"') {
      inQuotes = true;
    } else if (c === ',') {
      row.push(field);
      field = '';
    } else if (c === '\n') {
      row.push(field);
      rows.push(row);
      row = [];
      field = '';
    } else {
      field += c;
    }
  }
  if (field.length > 0 || row.length > 0) {
    row.push(field);
    rows.push(row);
  }
  return rows.filter((r) => !(r.length === 1 && r[0] === ''));
}

module.exports = { DataLoader, parseCsv, coerceValue };
