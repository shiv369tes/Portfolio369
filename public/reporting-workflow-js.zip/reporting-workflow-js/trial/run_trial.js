'use strict';
// Regenerates the trial dataset's profile using this repo's own data_ingestion module.
// Usage: node trial/run_trial.js
const fs = require('fs');
const path = require('path');
const { ingestAndProfile } = require('../src/data_ingestion');
const { setupLogging } = require('../src/utils/logging');

setupLogging('WARNING');

(async () => {
  const csvPath = path.join(__dirname, 'sales_trial.csv');
  const profile = await ingestAndProfile(csvPath, {
    missing_threshold: 0.8,
    impute_threshold: 0.1,
    outlier_method: 'iqr',
    zscore_threshold: 3,
    autoClean: true,
  });

  console.log('Original shape:', profile.originalShape);
  console.log('Cleaned shape:', profile.cleanedTable.shape);
  console.log('Missing summary:', profile.missingSummary);
  console.log('Outlier summary:', profile.outlierSummary);
  console.log('Recommendations:', profile.recommendations);

  fs.writeFileSync(
    path.join(__dirname, 'profile_output.json'),
    JSON.stringify(profile.toDict(), null, 2)
  );
  console.log('Saved -> trial/profile_output.json');
})();
